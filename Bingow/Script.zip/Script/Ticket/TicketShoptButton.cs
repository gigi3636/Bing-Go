using Godot;

// Script in  each shop button
public partial class TicketShoptButton : TextureButton
{
    private TicketData ticketRequestedData;
    [Export] private PlayerStatus playerStatusRes;
    [Export] private TicketShoptJuice ticketShoptJuiceRef;

    public void Initialize(TicketData pTicketRequestedData)
    {
        ticketRequestedData = pTicketRequestedData;

    }

    private void _on_pressed()
    {

        // Check if the purchase can be done 
        if (ticketRequestedData.Cost <= playerStatusRes.playerCurrentMoney)
        {
            playerStatusRes.DiscountMoney(ticketRequestedData.Cost);

            // Request to create a new ticket with a specific data
            TicketEventBus.PublishTicketRequested(ticketRequestedData, false);

            ticketShoptJuiceRef.OnButtonClicked(this);

        }
    }
}
